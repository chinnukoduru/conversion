package com.playsafe.conversion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.playsafe.conversion.dto.request.ConversionRequestDto;
import com.playsafe.conversion.service.api.ConversionService;
import com.playsafe.conversion.service.impl.ConversionServiceImpl;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class ConversionApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConversionApplication.class, args);
        
        ConversionService conversionService=new ConversionServiceImpl();
        ConversionRequestDto conversionRequestDto=new ConversionRequestDto();
        conversionRequestDto.setInputUnitOfMeasure("Fahrenheit");
        conversionRequestDto.setOutputUnitOfMeasure("Rankine");
        conversionRequestDto.setStudentRequest(84.2);
        conversionRequestDto.setItudentResponse(543.94);
        String response=conversionService.validateConversionsRequest(conversionRequestDto);
        System.out.println("response"+response);        
    }
    @Bean
    public Docket productApi() {
       return new Docket(DocumentationType.SWAGGER_2).select()
          .apis(RequestHandlerSelectors.basePackage("com.playsafe.conversion.controller")).build();
    }

}
