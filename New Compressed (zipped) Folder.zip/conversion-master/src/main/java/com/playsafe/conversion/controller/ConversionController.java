package com.playsafe.conversion.controller;

import com.playsafe.conversion.dto.request.ConversionRequestDto;
import com.playsafe.conversion.service.api.ConversionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/conversions")
public class ConversionController {

    @Autowired
    private ConversionService conversionService;

    @PostMapping("/converter")
    public String unitsConversionValidator(@Valid @RequestBody ConversionRequestDto conversionRequestDto) {        
		/*
		 * conversionRequestDto.setInputUnitOfMeasure("Fahrenheit");
		 * conversionRequestDto.setOutputUnitOfMeasure("Rankine");
		 * conversionRequestDto.setStudentRequest(84.2);
		 * conversionRequestDto.setItudentResponse(543.94);
		 */
        return conversionService.validateConversionsRequest(conversionRequestDto);
    }


}
