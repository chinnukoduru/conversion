package com.playsafe.conversion.service.api;

import com.playsafe.conversion.dto.request.ConversionRequestDto;

public interface ConversionService {
    
    String validateConversionsRequest(ConversionRequestDto conversionRequestDto);


}
