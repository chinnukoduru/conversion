package com.playsafe.conversion.dto.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

public class ConversionRequestDto {

	private double itudentResponse;
	private String inputUnitOfMeasure;
	private String outputUnitOfMeasure;
	private double studentRequest;
	public double getItudentResponse() {
		return itudentResponse;
	}
	public void setItudentResponse(double itudentResponse) {
		this.itudentResponse = itudentResponse;
	}
	public String getInputUnitOfMeasure() {
		return inputUnitOfMeasure;
	}
	public void setInputUnitOfMeasure(String inputUnitOfMeasure) {
		this.inputUnitOfMeasure = inputUnitOfMeasure;
	}
	public String getOutputUnitOfMeasure() {
		return outputUnitOfMeasure;
	}
	public void setOutputUnitOfMeasure(String outputUnitOfMeasure) {
		this.outputUnitOfMeasure = outputUnitOfMeasure;
	}
	public double getStudentRequest() {
		return studentRequest;
	}
	public void setStudentRequest(double studentRequest) {
		this.studentRequest = studentRequest;
	}

}
