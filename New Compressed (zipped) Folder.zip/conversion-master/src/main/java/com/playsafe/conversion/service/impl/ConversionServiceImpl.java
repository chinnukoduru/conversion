package com.playsafe.conversion.service.impl;

import com.playsafe.conversion.dto.request.ConversionRequestDto;
import com.playsafe.conversion.service.api.ConversionService;
import com.playsafe.conversion.utils.ConversionConstants;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

@Service
public class ConversionServiceImpl implements ConversionService {
	
    Stream<String> unitsStream = Stream.of("Fahrenheit","Rankine","Kelvin","Celsius");

	@Override
	public String validateConversionsRequest(ConversionRequestDto conversionRequestDto) {
		String output="Issue with processing";
		if(conversionRequestDto.getInputUnitOfMeasure()!=null && conversionRequestDto.getOutputUnitOfMeasure()!=null) {
			boolean inputMatch = ConversionConstants.streamSupplier.get().anyMatch(s -> s.toLowerCase().contains(conversionRequestDto.getInputUnitOfMeasure().toLowerCase()));
			ConversionConstants.unitsStream.close();
	        boolean outputMatch =ConversionConstants.streamSupplier.get().anyMatch(s -> s.toLowerCase().contains(conversionRequestDto.getOutputUnitOfMeasure().toLowerCase()));
	        if(inputMatch && outputMatch ) {
	        	String methodName=conversionRequestDto.getInputUnitOfMeasure()+"To"+conversionRequestDto.getOutputUnitOfMeasure();
	            if(conversionRequestDto.getInputUnitOfMeasure().toLowerCase().contains("celsius"))
	            {
	            Double CtoF=CtoF(conversionRequestDto.getStudentRequest());
	            Double CtoK=CtoK(conversionRequestDto.getStudentRequest());
	            Double CtoRa=CtoRa(conversionRequestDto.getStudentRequest());
	            Stream<String> outputStream = Stream.of(Double.toString(CtoF),Double.toString(CtoK),Double.toString(CtoRa));
				if (outputStream
						.anyMatch(s -> s.contains(Double.toString(conversionRequestDto.getItudentResponse())))) {
					return "correct";
				} else {
					return "incorrect";

				}
			}
	        else if(conversionRequestDto.getInputUnitOfMeasure().toLowerCase().contains("fahrenheit"))
	            {
	        	 Double FtoC=FtoC(conversionRequestDto.getStudentRequest());
	        	 Double FtoK=FtoK(conversionRequestDto.getStudentRequest());
	        	 Double FtoRa=FtoRa(conversionRequestDto.getStudentRequest());
		         Stream.of(Double.toString(FtoC),Double.toString(FtoK),Double.toString(FtoRa)).forEach(System.out::println);

		         Stream<String> outputStream = Stream.of(Double.toString(FtoC),Double.toString(FtoK),Double.toString(FtoRa));
		         System.out.println(conversionRequestDto.getItudentResponse());
		     	if (outputStream
						.anyMatch(s -> s.contains(Double.toString(conversionRequestDto.getItudentResponse())))) {
					return "correct";
				} else {
					return "incorrect";

				}

	            }
	        else if(conversionRequestDto.getInputUnitOfMeasure().toLowerCase().contains("kelvin"))
	            {
	        	 Double KtoC= KtoC(conversionRequestDto.getStudentRequest());
	        	 Double KtoF= KtoF(conversionRequestDto.getStudentRequest());
	        	 Double KtoRa=KtoRa(conversionRequestDto.getStudentRequest());
		         Stream<String> outputStream = Stream.of(Double.toString(KtoC),Double.toString(KtoF),Double.toString(KtoRa));
		     	if (outputStream
						.anyMatch(s -> s.contains(Double.toString(conversionRequestDto.getItudentResponse())))) {
					return "correct";
				} else {
					return "incorrect";

				}

	            }
	        else if(conversionRequestDto.getInputUnitOfMeasure().toLowerCase().contains("rankine"))
	            {
	        	 Double RatoC=RatoC(conversionRequestDto.getStudentRequest());
	        	 Double RatoF=RatoF(conversionRequestDto.getStudentRequest());
	        	 Double RatoK= RatoK(conversionRequestDto.getStudentRequest());
		          Stream<String> outputStream = Stream.of(Double.toString(RatoC),Double.toString(RatoF),Double.toString(RatoK));
		      	if (outputStream
						.anyMatch(s -> s.contains(Double.toString(conversionRequestDto.getItudentResponse())))) {
					return "correct";
				} else {
					return "incorrect";

				}

	            }
	        }else {
	        	return "invalid";
	        }
		}
		else {
			return "invalid input";
		}
        
		return output;
	}

	
	
	public double CtoF(double c) {
		double f = c * 9.0f / 5.0f + 32;
		BigDecimal bd = new BigDecimal(f).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double CtoK(double c) {
		double k = c + 273.15f;
		BigDecimal bd = new BigDecimal(k).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double CtoRa(double c) {
		double ra = (c + 273.15f) * 9f / 5f;
		BigDecimal bd = new BigDecimal(ra).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double FtoC(double f) {
		double c = (f - 32) * 5f / 9f;
		BigDecimal bd = new BigDecimal(c).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double FtoK(double f) {
		double k = (f + 459.67f) * 5f / 9f;
		BigDecimal bd = new BigDecimal(k).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double FtoRa(double f) {
		double ra = f + 459.67f;
		BigDecimal bd = new BigDecimal(ra).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double KtoC(double k) {
		double c = k - 273.15f;
		BigDecimal bd = new BigDecimal(c).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double KtoF(double k) {
		double f = k * 9f / 5f - 459.67f;
		BigDecimal bd = new BigDecimal(f).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double KtoRa(double k) {
		double ra = k * 9f / 5f;
		BigDecimal bd = new BigDecimal(ra).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RetoC(double re) {
		double c = re * 5f / 4f;
		BigDecimal bd = new BigDecimal(c).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RetoF(double re) {
		double f = re * 9f / 4f + 32;
		BigDecimal bd = new BigDecimal(f).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RetoK(double re) {
		double k = re * 5f / 4f + 273.15f;
		BigDecimal bd = new BigDecimal(k).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RetoRa(double re) {
		double ra = re * 9f / 4f + 491.67f;
		BigDecimal bd = new BigDecimal(ra).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RatoC(double ra) {
		double c = (ra - 491.67f) * 5f / 9f;
		BigDecimal bd = new BigDecimal(c).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RatoF(double ra) {
		double f = ra - 459.67f;
		BigDecimal bd = new BigDecimal(f).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

	public double RatoK(double ra) {
		double k = ra * 5f / 9f;
		BigDecimal bd = new BigDecimal(k).setScale(2, RoundingMode.HALF_DOWN);
		return bd.doubleValue();
	}

}
