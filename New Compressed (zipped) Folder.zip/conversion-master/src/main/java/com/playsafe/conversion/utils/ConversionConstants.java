package com.playsafe.conversion.utils;

import java.util.function.Supplier;
import java.util.stream.Stream;

public interface ConversionConstants {



    double KELVIN_TO_CELCIOUS_RATE=273.15;

    double MILE_TO_KILOMETER_RATE = 1.609344;

    double KILOMETER_TO_MILE_RATE = 0.6213711922;

    Stream<String> unitsStream = Stream.of("Fahrenheit","Rankine","Kelvin","Celsius");
    
    
    Supplier<Stream<String>> streamSupplier 
    = () -> Stream.of("Fahrenheit","Rankine","Kelvin","Celsius");

}
