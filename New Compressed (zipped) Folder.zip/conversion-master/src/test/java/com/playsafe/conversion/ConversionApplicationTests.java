package com.playsafe.conversion;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ConversionApplicationTests {

    @Test
    public void contextLoads() {
    }

}
