# conversion
## This is a springboot application to run it simple
- clone the project
- mvn clean install
- Open terminal and run java -jar target/conversion-0.0. 1-SNAPSHOT.jar.

## The ends points functions

- /conversions/ktoc -- This endpoint accepts a kevin amount to be converted to celcius

- /conversions/ctok -- This endpoint accepts a celcius amount to be converted to kevin

- /conversions/mtok -- This endpoint accepts a miles input to be converted to kilometers

- /conversions/ktom -- This endpoint accepts a kilometers input to be converted to miles
